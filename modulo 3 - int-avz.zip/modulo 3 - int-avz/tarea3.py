#crear un archivo .py, dentro definir 2 funciones y usarlas en otro archivo

#crear un juego de pelotas va a haber 5 colores , de las cuales del primer color haya  5 del 
#del segundo 4 , del tercero 3, del segundo 2 y del primero 1.
#le preguntaras al usuario cuanto quieres apostar, y mientras mas bajo el numero de color de pelota
#mas a la potencia se elevara su apuesto , si no gana le dices womp womp gana la casa!

#crea un script que:
#1. Pida el nombre del usuario
#2. Elija aleatoriamente un mensaje de bienvenida
#3. Imprima la fecha y ahora actual