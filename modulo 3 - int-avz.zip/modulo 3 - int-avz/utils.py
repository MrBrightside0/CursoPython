#funcion que salude al usuario
def saludar(nombre):
    return f'Hola {nombre}, bienvenido al curso!'

#funcion que eleve al cuadrado
def cuadrado(n):
    return n**2
